<?php
/**
 * @link https://www.yiiframework.com/
 * @copyright Copyright (c) 2008 Yii Software LLC
 * @license https://www.yiiframework.com/license/
 */

namespace yii\debug\models;

/**
 * @deprecated since 2.1.14 please use \yii\debug\models\router\CurrentRoute instead
 */
class Router extends \yii\debug\models\router\CurrentRoute
{
}
